#!/usr/bin/env python3
"""
preflight.py — one‑screen sanity check for Igris config.

This script validates your assistant identity and task intent files before you
launch the Igris CLI or GUI.  It verifies that required fields are present,
detects duplicate task names and phrases, and reports any schema issues in
human‑readable form.  It can be run manually or imported as a module.

Usage: simply execute this file directly:

    python3 preflight.py

The script will search for your configuration files in a few common
locations, including the current directory and the `ai_assistant_config/`
subdirectory.  If found, it will parse and validate them; otherwise, it will
report that they are missing.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from collections import Counter
from typing import Any, Dict, List

###############################################################################
# Helpers to locate and load JSON configuration files
###############################################################################

# Potential locations for the identity and intents files.  These are searched
# in order until a file is found.
CANDIDATE_ID_PATHS = [
    Path("assistant_identity.json"),
    Path("ai_assistant_config/assistant_identity.json"),
    Path.home() / "OneDrive" / "Documents" / "assistant_identity.json",
]
CANDIDATE_TASK_PATHS = [
    Path("task_intents.json"),
    Path("ai_assistant_config/task_intents.json"),
]
CANDIDATE_GUI_TAGS = [
    Path("task_intents_gui_tags.json"),
    Path("ai_assistant_config/task_intents_gui_tags.json"),
]


def _first_existing(paths: List[Path]) -> Path | None:
    """Return the first path in `paths` that exists on disk, or None."""
    for p in paths:
        if p.exists():
            return p
    return None


def _load_json(path: Path) -> Any:
    """Safely load a JSON file and return the parsed data, or None on error."""
    try:
        with path.open(encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


###############################################################################
# Identity validation
###############################################################################

def lint_identity() -> Dict[str, Any]:
    """
    Check that the assistant identity file exists and contains the required
    fields.  Returns a dict describing the result.
    """
    p = _first_existing(CANDIDATE_ID_PATHS)
    issues: List[str] = []
    data: Dict[str, Any] = {}
    if not p:
        issues.append("assistant_identity.json: NOT FOUND")
        return {"path": None, "ok": False, "issues": issues, "data": {}}

    loaded = _load_json(p)
    if not isinstance(loaded, dict):
        return {"path": p, "ok": False, "issues": ["assistant_identity.json is not a JSON object"], "data": {}}
    data = loaded
    # Required string fields
    for k in ("name", "role", "base_context"):
        if not isinstance(data.get(k), str) or not data.get(k).strip():
            issues.append(f"identity.{k} missing or not a non‑empty string")
    return {"path": p, "ok": not issues, "issues": issues, "data": data}


###############################################################################
# Task intents validation
###############################################################################

def lint_task_intents() -> Dict[str, Any]:
    """
    Validate the task intents file.  Ensures the top‑level structure is a dict
    with a `tasks` list, checks for duplicate task names and phrases, and
    records counts of missing fields and type mismatches.  Returns a summary.
    """
    p = _first_existing(CANDIDATE_TASK_PATHS)
    issues: List[str] = []
    if not p:
        issues.append("task_intents.json: NOT FOUND")
        return {"path": None, "ok": False, "issues": issues, "counts": {}}

    loaded = _load_json(p)
    if not isinstance(loaded, dict) or not isinstance(loaded.get("tasks"), list):
        issues.append("task_intents.json: root 'tasks' must be a list")
        return {"path": p, "ok": False, "issues": issues, "counts": {}}

    tasks = loaded["tasks"]
    task_names = [t.get("task") for t in tasks]
    dup_task_names = [t for t, c in Counter(task_names).items() if c > 1]
    if dup_task_names:
        issues.append("duplicate task names: " + ", ".join(sorted(map(str, dup_task_names))))

    phrase_counter = Counter()
    missing_fields = 0
    bad_requires_admin_types = 0
    for i, t in enumerate(tasks):
        # Required keys
        for key in ("task", "action", "phrases"):
            if key not in t:
                missing_fields += 1
        # requires_admin must be bool if present
        if "requires_admin" in t and not isinstance(t["requires_admin"], bool):
            bad_requires_admin_types += 1
        # Phrase validation
        ph = t.get("phrases", [])
        if not isinstance(ph, list) or any(not isinstance(s, str) or not s.strip() for s in ph):
            issues.append(f"task[{i}] '{t.get('task','?')}': 'phrases' must be list[str]")
        else:
            phrase_counter.update([s.strip().lower() for s in ph if isinstance(s, str)])

    dup_phrases = [p for p, c in phrase_counter.items() if c > 1]
    if dup_phrases:
        issues.append(
            "duplicate phrases across tasks: "
            + ", ".join(sorted(dup_phrases)[:10])
            + (" ..." if len(dup_phrases) > 10 else "")
        )

    return {
        "path": p,
        "ok": not issues,
        "issues": issues,
        "counts": {
            "tasks": len(tasks),
            "unique_phrases": len(phrase_counter),
            "missing_fields": missing_fields,
            "bad_requires_admin_types": bad_requires_admin_types,
        },
    }


###############################################################################
# GUI tags validation
###############################################################################

def lint_gui_tags() -> Dict[str, Any]:
    """
    Validate the task_intents_gui_tags.json file.  Ensures tags are lists and
    returns counts of each tag.  Missing file is not considered an error.
    """
    p = _first_existing(CANDIDATE_GUI_TAGS)
    if not p:
        return {"path": None, "ok": True, "issues": [], "tag_counts": {}}
    loaded = _load_json(p)
    issues: List[str] = []
    tag_counts: Counter[str] = Counter()
    if isinstance(loaded, dict) and isinstance(loaded.get("tasks"), list):
        for t in loaded["tasks"]:
            tag_list = t.get("tags", [])
            if tag_list and not isinstance(tag_list, list):
                issues.append(f"task '{t.get('task','?')}': tags must be a list")
            else:
                tag_counts.update(tag_list or [])
    else:
        issues.append("task_intents_gui_tags.json: expected object with 'tasks' list")
    return {"path": p, "ok": not issues, "issues": issues, "tag_counts": dict(tag_counts)}


###############################################################################
# Health report
###############################################################################

def health_report() -> str:
    """
    Generate a summary of configuration health.  This combines the results of
    identity, task intents and GUI tag validations into a single, human‑readable
    multi‑line string suitable for printing to the console.
    """
    idr = lint_identity()
    tir = lint_task_intents()
    tgr = lint_gui_tags()

    lines: List[str] = []
    lines.append("=== Igris Preflight — Config Health ===")
    # Identity summary
    lines.append(f"Identity: {idr['path'] or 'MISSING'}  |  OK: {idr['ok']}")
    if idr["issues"]:
        for s in idr["issues"][:5]:
            lines.append(f"  - {s}")
    # Task intents summary
    counts = tir.get("counts", {})
    lines.append(
        f"Intents:  {tir['path'] or 'MISSING'}  |  OK: {tir['ok']}  |  tasks={counts.get('tasks',0)}, phrases={counts.get('unique_phrases',0)}"
    )
    if tir["issues"]:
        for s in tir["issues"][:8]:
            lines.append(f"  - {s}")
    # GUI tags summary
    if tgr["path"]:
        lines.append(
            f"GUI Tags: {tgr['path']}  |  OK: {tgr['ok']}  |  tag‑kinds={len(tgr.get('tag_counts',{}))}"
        )
        if tgr["issues"]:
            for s in tgr["issues"][:5]:
                lines.append(f"  - {s}")
    lines.append("======================================")
    return "\n".join(lines)


def main() -> None:
    """
    Entry point for command‑line execution.  Prints the health report.
    """
    print(health_report())


if __name__ == "__main__":
    main()