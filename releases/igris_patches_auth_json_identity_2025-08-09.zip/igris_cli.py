
"""
Igris CLI — patched to:
  - Use shared admin authentication from igris_core.authenticate_admin
  - Always enforce JSON output via igris_core.ask_ollama
  - Load assistant identity with default merge (fix schema mismatch)
"""
import json, argparse, subprocess, shlex, sys
from pathlib import Path

from igris_core import (
    load_assistant_identity,
    ask_ollama,
    enforce_admin_then,
    parse_task_response,
)

def run_shell(cmd: str) -> int:
    print(f"[RUN] {cmd}")
    try:
        return subprocess.call(cmd, shell=True)
    except KeyboardInterrupt:
        return 130

def handle_intent(obj: dict) -> int:
    task, action, requires_admin = parse_task_response(obj)
    if not action:
        print("[WARN] No actionable 'action' found in response.")
        return 2

    def _do():
        return run_shell(action)

    try:
        return enforce_admin_then(_do, requires_admin=requires_admin)
    except PermissionError as e:
        print(f"[SECURITY] {e}")
        return 3

def main():
    p = argparse.ArgumentParser(description="Igris CLI (patched)")
    p.add_argument("--identity", type=Path, default=Path("assistant_identity.json"))
    p.add_argument("--model", default="llama3")
    p.add_argument("--system", default=None)
    p.add_argument("prompt", nargs="*", help="Freeform request")
    args = p.parse_args()

    ident = load_assistant_identity(args.identity)
    user_req = " ".join(args.prompt).strip()
    if not user_req:
        print("Example: igris_cli.py \"Run disk cleanup as admin\"")
        sys.exit(1)

    system_prefix = None
    if args.system:
        system_prefix = args.system
    else:
        # Use identity context as system preface
        system_prefix = f"{ident['role']}. {ident['base_context']}"

    # Call Ollama via core wrapper
    obj = ask_ollama(
        prompt=user_req,
        model=args.model,
        system_prefix=system_prefix,
        force_json=True
    )

    # If the model returned a raw wrapper, inform the user
    if "_raw" in obj and "status" in obj:
        print("[INFO] Ollama unavailable; running in dry-run parse mode.")
    rc = handle_intent(obj)
    sys.exit(int(rc or 0))

if __name__ == "__main__":
    main()
