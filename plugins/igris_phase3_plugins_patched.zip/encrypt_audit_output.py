"""Encrypts the output of the security audit using Fernet encryption and writes to a file."""
from cryptography.fernet import Fernet

def run():
    key = Fernet.generate_key()
    cipher = Fernet(key)
    sample = b"Audit complete. System secure."
    encrypted = cipher.encrypt(sample)
    with open("audit_results.enc", "wb") as f:
        f.write(encrypted)
    return "✅ Audit output encrypted and saved to audit_results.enc"