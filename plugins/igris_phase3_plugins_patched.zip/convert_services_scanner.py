"""Scans mock Windows services and returns weak ones."""
def run():
    weak_services = ["Telnet", "FTP", "Remote Registry"]
    report = "\n".join(f"- {svc}" for svc in weak_services)
    return f"⚠️ Weak services found:\n{report}"