"""Scans for simulated anomalies in running processes."""
def run():
    suspicious = ["unverified_app.exe", "malware_sim.exe"]
    return f"🚨 Anomalies Detected:\n" + "\n".join(suspicious)