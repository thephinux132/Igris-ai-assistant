"""
Auto-generated Igris Plugin: Plugin Execution Logger
"""

def run():
    ```python
    # Initialize an empty list to store names
    names = []

    # Add names from user input
    names.append(input("Enter name: "))
    names.append(input("Enter age: "))
    names.append(input("Enter city: "))

    # Print the names with their corresponding ages and cities
    for i, name in enumerate(names):
        print(f"Name {i+1}: {name}, Age: {names[i]}, City: {names[i+1]}")
    ```
    return '✅ plugin_execution_logger plugin executed.'
