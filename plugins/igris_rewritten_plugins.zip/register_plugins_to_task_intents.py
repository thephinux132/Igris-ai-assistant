"""Register Plugins to Task Intents - Simulated Generator"""
import os

def run():
    plugins = [f for f in os.listdir("plugins") if f.endswith(".py")]
    return f"Found and registered {len(plugins)} plugins: " + ", ".join(plugins)