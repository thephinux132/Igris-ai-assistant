"""
Phase 4 Launcher
Simple GUI dashboard to trigger Phase 4 plugins.
"""
import tkinter as tk
import importlib.util
from pathlib import Path

def run_plugin(name):
    plugin_path = Path("plugins") / f"{name}.py"
    spec = importlib.util.spec_from_file_location(name, plugin_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if hasattr(mod, "run"):
        output = mod.run()
        result_box.delete("1.0", tk.END)
        result_box.insert(tk.END, output)

def run():
    root = tk.Tk()
    root.title("Phase 4 Toolkit")
    root.geometry("600x400")

    global result_box
    result_box = tk.Text(root, height=15, wrap=tk.WORD)
    result_box.pack(pady=10)

    btn_frame = tk.Frame(root)
    btn_frame.pack()

    buttons = {
        "Ping Sweep": "ping_sweep",
        "Who is Connected": "who_is_connected",
        "Port Scanner": "port_scanner",
        "Phase 4 Diagnostic": "phase4_diagnostic"
    }

    for label, plugin in buttons.items():
        b = tk.Button(btn_frame, text=label, width=20, command=lambda p=plugin: run_plugin(p))
        b.pack(side=tk.LEFT, padx=5)

    root.mainloop()
    return "Phase 4 GUI opened."
