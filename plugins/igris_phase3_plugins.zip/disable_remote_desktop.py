"""Disable Remote Desktop - Executes registry command to disable RDP"""
import subprocess

def run():
    try:
        cmd = [
            "powershell",
            "-Command",
            "Set-ItemProperty -Path 'HKLM:\\System\\CurrentControlSet\\Control\\Terminal Server' -Name 'fDenyTSConnections' -Value 1"
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, shell=True)
        return "Remote Desktop disabled." if result.returncode == 0 else result.stderr
    except Exception as e:
        return f"Failed to disable RDP: {e}"