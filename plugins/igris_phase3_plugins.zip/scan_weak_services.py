"""Scan Weak Services - Lists insecure legacy Windows services"""
def run():
    weak = ['Telnet', 'Remote Registry', 'FTP', 'SNMP', 'NetBIOS']
    return "Weak Services Found:\n" + "\n".join(weak)