"""
Phase 4 Diagnostic Plugin

Scans local network, checks for open ports, and logs login anomalies.
"""
import socket
import subprocess
import platform

def run():
    try:
        # Get local IP prefix
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        subnet_prefix = ".".join(local_ip.split(".")[:3])

        # Basic ping sweep for .1 to .254
        live_hosts = []
        for i in range(1, 255):
            ip = f"{subnet_prefix}.{i}"
            result = subprocess.run(
                ["ping", "-n", "1", "-w", "300", ip] if platform.system() == "Windows" else ["ping", "-c", "1", "-W", "1", ip],
                stdout=subprocess.DEVNULL
            )
            if result.returncode == 0:
                live_hosts.append(ip)

        # Log results
        return f"Live Hosts:
" + "\n".join(live_hosts)
    except Exception as e:
        return f"[ERROR] {str(e)}"
