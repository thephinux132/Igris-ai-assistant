"""Scans /plugins and registers all plugin names + docstrings into task_intents.json."""
import json
from pathlib import Path

def run():
    plugins_dir = Path("plugins")
    intents_path = Path("ai_assistant_config") / "task_intents.json"

    if not intents_path.exists():
        return "❌ task_intents.json not found."

    try:
        existing = json.loads(intents_path.read_text(encoding="utf-8"))
    except:
        existing = {"tasks": []}

    for file in plugins_dir.glob("*.py"):
        if file.name.startswith("__"): continue
        name = file.stem
        doc = file.read_text(encoding="utf-8").split('"""')
        desc = doc[1].strip() if len(doc) > 2 else "No description"
        task = {
            "task": name.replace("_", " "),
            "phrases": [f"run {name}", f"launch {name}"],
            "action": f"plugin:{name}",
            "requires_admin": False,
            "result": desc
        }
        existing["tasks"] = [t for t in existing["tasks"] if t.get("task") != task["task"]]
        existing["tasks"].append(task)

    intents_path.write_text(json.dumps(existing, indent=2), encoding="utf-8")
    return f"✅ Registered {len(existing['tasks'])} plugins to task_intents.json."