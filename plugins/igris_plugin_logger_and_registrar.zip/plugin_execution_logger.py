"""Logs each plugin execution with timestamp into ai_memory.json."""
import json
from datetime import datetime
from pathlib import Path

def run():
    log_file = Path.home() / "OneDrive" / "Documents" / "ai_memory.json"
    log_entry = {
        "plugin": "plugin_execution_logger",
        "timestamp": datetime.now().isoformat()
    }
    try:
        if log_file.exists():
            data = json.loads(log_file.read_text(encoding="utf-8"))
        else:
            data = []
    except:
        data = []

    data.append(log_entry)
    log_file.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return f"🧠 Plugin execution logged at {log_entry['timestamp']}"