
""" 
alert_on_new_hosts.py

Scans for new hosts on local network. 
Logs timestamped alerts to ai_script_log.txt and notifies via popup + voice.
Runs on boot if added to autorun_plugins.
Can run persistently if imported into a background thread.
"""

import json
import os
import platform
import subprocess
from pathlib import Path
from tkinter import messagebox, Tk
import pyttsx3
from datetime import datetime
import time

KNOWN_HOSTS_FILE = Path("ai_assistant_config/known_hosts.json")
LOG_FILE = Path(os.path.expanduser("~")) / "OneDrive" / "Documents" / "ai_script_log.txt"

def get_current_hosts():
    try:
        result = subprocess.run(["arp", "-a"], capture_output=True, text=True, timeout=10)
        lines = result.stdout.splitlines()
        hosts = []
        for line in lines:
            if '-' in line or "dynamic" in line.lower() or "static" in line.lower():
                parts = line.split()
                if len(parts) >= 2:
                    hosts.append(parts[0])
        return sorted(set(hosts))
    except Exception as e:
        return []

def load_known_hosts():
    try:
        if KNOWN_HOSTS_FILE.exists():
            return json.loads(KNOWN_HOSTS_FILE.read_text(encoding='utf-8'))
    except:
        pass
    return []

def save_known_hosts(hosts):
    try:
        KNOWN_HOSTS_FILE.parent.mkdir(parents=True, exist_ok=True)
        KNOWN_HOSTS_FILE.write_text(json.dumps(sorted(set(hosts)), indent=2), encoding='utf-8')
    except:
        pass

def speak(msg):
    try:
        engine = pyttsx3.init()
        engine.say(msg)
        engine.runAndWait()
    except:
        pass

def popup(msg):
    try:
        root = Tk()
        root.withdraw()
        messagebox.showinfo("Igris Alert", msg)
        root.destroy()
    except:
        pass

def log_event(entry):
    try:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_msg = f"[{timestamp}] [NEW_HOST_ALERT] {entry}\n"
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(log_msg)
    except:
        pass

def run_once():
    old_hosts = load_known_hosts()
    new_hosts = get_current_hosts()
    added = [h for h in new_hosts if h not in old_hosts]
    if added:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        alert_msg = f"⚠️ New device(s) detected @ {ts}:
" + "\n".join(added)
        speak("New device detected on your network.")
        popup(alert_msg)
        save_known_hosts(new_hosts)
        log_event(", ".join(added))
        return alert_msg
    else:
        return "No new hosts detected."

def run():
    # For persistent mode, loop every 2 minutes. Otherwise just run once.
    PERSISTENT = False  # Change to True if background task manager will launch this
    if not PERSISTENT:
        return run_once()
    while True:
        run_once()
        time.sleep(120)  # 2 min delay
