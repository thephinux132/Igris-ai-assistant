"""
Auto-generated Igris Plugin for Enable Windows Firewall
"""

def run():
    # Code generated for: Write a PowerShell command that enables the Windows Firewall on all profiles.
    print("Write a PowerShell command that enables the Windows Firewall on all profiles.")
    return '✅ enable_windows_firewall executed.'
