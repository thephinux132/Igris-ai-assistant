"""
Auto-generated Igris Plugin for Disable Remote Desktop
"""

def run():
    # Code generated for: Write a PowerShell command that disables Windows Remote Desktop by modifying the registry.
    print("Write a PowerShell command that disables Windows Remote Desktop by modifying the registry.")
    return '✅ disable_remote_desktop executed.'
